exports.handler = async (event) => {
    
    function getCombinations(chars) {
        var result = [];
        var f = function(prefix, chars) {
            for (var i = 0; i < chars.length; i++) {
                result.push(prefix + chars[i]);
                f(prefix + chars[i], chars.slice(i + 1));
            }
        }
        f('', chars);
        return result;
    }
    
    /*
    * @params chars An Array of characters that correspond to each number in phoneNumber
    * @returns words An Array of words that were made by combining characters and alternating vowels and consonants
    */
    function getWords(chars){
        const vowels = ['a', 'e', 'i', 'o', 'y'];
        //loop through array of characters and choose a letter from the char_map[index]
        
        for(let i = 0; i < chars.length; i++){
            
        }
        
    }
    
    function convertToVanity(phoneNumber){
        let char_map = ["0", "1", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"];
        // remove the 3 first numbers since that is the area code of the number and keep the same
        const areaCode = phoneNumber.substr(0, 3);
        console.log("Area Code: ", areaCode);
        
        phoneNumber = phoneNumber.substr(3);
        console.log("New Phone Number", phoneNumber);
        
        let vanityPhoneNumber = []; //output_arr, array for the result of the permutation
        console.log("Vanity Phone Number: ", vanityPhoneNumber);
        console.log("Vanity Phone Number Length: ", vanityPhoneNumber.length);
        
        let charArray = [];
        for(let i = 0; i < phoneNumber.length; i++){ //looping through phone number array 
            let numberIndex = phoneNumber.charAt(i); // getting the numberic value of the index that we need in the char_map
            console.log("Number Index: ", numberIndex); 
            // put all the letters into an array 
            for(let i = 0; i < char_map[numberIndex].length; i++){
                charArray.push(char_map[numberIndex].charAt(i));
            }

            /*while(vanityPhoneNumber.length == i ){
                let permutation = vanityPhoneNumber.pop();
                //create a char array of the numberIndex
                let charArray = [];
                for(let i = 0; i < char_map[numberIndex].length; i++){
                    charArray.push(char_map[numberIndex].charAt(i));
                }
                console.log("Character Array: ", charArray);
                console.log("Permutation: ", permutation);
                for(let c of charArray){
                    console.log("This is c: ", c);
                    vanityPhoneNumber.push(permutation + c);
                }
            }*/
        }
        console.log(getCombinations(charArray));
     }
    
    // receive a phone number and strip of all special characters
    console.log("event.phone: ", event.phone);
    let phoneNumber = event.phone.replace(/[^0-9]/g, '');
    console.log("Phone Number: ", phoneNumber);
    //validate the number by making sure it is less than 10 digits
    // might need a validate function or might be good to just do it here 
    console.log("Phone Number length: ", phoneNumber.length);
    /*if(phoneNumber.length <= 9 || phoneNumber.lenth > 15){
        console.log("Please enter a valid phone number");
    }else{*/
        console.log(phoneNumber, ": is a normal number!!");
        //here we want to put the phone number through a switch statement
        //to spit out letters 
        //have to determine whether it is a 10 digit number, 11 digit where it has a 1 like 1-800, has 15 digits I guess... need to figure that out 
        // maybe this is a question I should ask about but I can test with 10 digit numbers for now 
        convertToVanity(phoneNumber);
        
    //}
    
    // turn them into vanity numbers and return the first 3
    
};