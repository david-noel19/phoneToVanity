exports.handler = async (event) => {
  // import resources
  const checkWord = require("check-word");
  const aws = require("aws-sdk");
  const { v4 } = require("uuid");

  // initialize resources
  const dictionary = checkWord("en");
  const dynamodb = new aws.DynamoDB.DocumentClient();
  const tableName = process.env.TABLENAME;
  console.log("tableName: ", tableName);

  let phoneNumber = "";
  if (event["Details"]["Parameters"]["customerPhoneNumber"]) {
    phoneNumber = event["Details"]["Parameters"]["customerPhoneNumber"];
  }
  const digits = phoneNumber.slice(-10, -4);
  const digitsToConvert = phoneNumber.slice(-4);
  const char_map = {
    0: "0",
    1: "1",
    2: "abc",
    3: "def",
    4: "ghi",
    5: "jkl",
    6: "mno",
    7: "pqrs",
    8: "tuv",
    9: "wxyz",
  };
  let vanityNumbers = [];

  function letterCombinations(digits) {
    let result = [];
    if (!digits.length) {
      return [];
    }
    function getCombinations(pointer, combination) {
      if (pointer === digits.length) {
        result.push(combination);
      } else {
        let letters = char_map[digits[pointer]];
        for (let i = 0; i < letters.length; i++) {
          getCombinations(pointer + 1, combination + letters[i]);
        }
      }
    }
    getCombinations(0, "");
    return result;
  }

  function getVanity(combination, digitsToConvert, digits) {
    let finalVanity = "";
    let partialVanity = "";
    let partialNumber = "";
    // console.log(finalVanity, finalVanity.length);
    // error handling
    if (!combination.length) {
      return finalVanity;
    }
    // console.log("hasWord before entering the first for loop: ", finalVanity);
    for (let i = 0; i < combination.length; i++) {
      partialVanity = combination.substr(i);
      partialNumber = digitsToConvert.substr(i);
      for (let j = partialVanity.length; j > 3; j--) {
        let pWord = partialVanity.substr(0, j),
          pNumber = partialNumber.substr(0, j);
        // console.log("This is possible word: ", pWord);
        if (dictionary.check(pWord)) {
          //   console.log("this is the exit point: ", pWord);
          finalVanity = digits + digitsToConvert.replace(pNumber, pWord);
          break;
        }
      }
      if (finalVanity.length) break;
    }
    return finalVanity;
  }

  function letterCount(str) {
    let count = 0;
    for (let i = 0; i < str.length; i++) {
      if (str[i].match(/[a-z]/i)) {
        count++;
      }
    }
    return count;
  }

  const combinations = letterCombinations(digitsToConvert);
  // console.log("Combinations: ", combinations);
  // combinations.forEach((combination) => console.log(combination));
  combinations.forEach((combination) => {
    // console.log("Combination: ", combination);
    const vanity = getVanity(combination, digitsToConvert, digits);
    if (vanity.length) {
      //get rid of duplicates
      if (!vanityNumbers.includes(vanity)) {
        vanityNumbers.push(vanity);
      }
    }
  });

  // console.log("VanityNumbers before the if: ", vanityNumbers);

  if (vanityNumbers.length) {
    if (vanityNumbers.length < 3) {
      console.log("vanityNumbers.length: ", vanityNumbers.length);
      let difference = 3 - vanityNumbers.length;
      let extraCombinations = combinations.slice(0, difference);
      extraCombinations.forEach((extra) => vanityNumbers.push(digits + extra));
    }
    // save if any of the vanities have 4 letter words
    let possibleBest = [],
      count = 0;
    for (let i = 0; i < vanityNumbers.length; i++) {
      if (letterCount(vanityNumbers[i]) > count) {
        possibleBest.splice(0, 1, vanityNumbers[i]);
        count = letterCount(vanityNumbers[i]);
      }
    }
    if (possibleBest.length && letterCount(possibleBest[0]) > 3) {
      //save to dynamoDB
      const params = {
        TableName: tableName,
        Item: {
          id: v4(),
          customerPhoneNumber: phoneNumber,
          vanity: possibleBest[0],
        },
      };
      try {
        const save = await dynamodb.put(params).promise();
        console.log("Save: ", save);
        console.log("Should save to Dynamo: ", possibleBest[0]);
      } catch (err) {
        console.log(err);
      }
    }
  }

  let ssml = "<speak>Your possible vanity numbers are";
  if (vanityNumbers.length) {
    vanityNumbers = vanityNumbers.splice(3);
    vanityNumbers.forEach((item) => (ssml = ssml + "<break/>" + item));
  } else {
    ssml =
      ssml + "There are no phonetic vanity numbers for your number. Goodbye.";
  }
  ssml = ssml + "</speak>";
  let response = { vanityNumbers: ssml };

  console.log(response);

  return response;
};
