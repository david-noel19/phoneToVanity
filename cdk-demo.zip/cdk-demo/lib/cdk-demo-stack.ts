import * as cdk from "@aws-cdk/core";
import * as lambda from "@aws-cdk/aws-lambda";
import * as dynamoDB from "@aws-cdk/aws-dynamodb";

export class CdkDemoStack extends cdk.Stack {
  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    /**
     * Create a dynamoDB Table for the 5 best vanities and numbers
     */
    const bestVanities = new dynamoDB.Table(this, "bestVanities", {
      partitionKey: { name: "id", type: dynamoDB.AttributeType.STRING },
    });

    /**
     * Create 2 lambda layers to be used in convertToVanity lambda
     */
    const checkWord = new lambda.LayerVersion(this, "checkWord", {
      code: lambda.Code.fromAsset("lambdaLayer/checkWord.zip"),
      description: "Node package to help identify words",
      compatibleRuntimes: [lambda.Runtime.NODEJS_14_X],
    });
    const uuid = new lambda.LayerVersion(this, "uuid", {
      code: lambda.Code.fromAsset("lambdaLayer/uuid.zip"),
      description: "Node package to create uuids",
      compatibleRuntimes: [lambda.Runtime.NODEJS_14_X],
    });

    /**
     * Create lambda function
     */
    const convertToVanityLambda = new lambda.Function(this, "convertToVanity", {
      code: lambda.Code.fromAsset("lambda"),
      handler: "convertToVanity.handler",
      runtime: lambda.Runtime.NODEJS_14_X,
      environment: {
        TABLENAME: bestVanities.tableName,
      },
      layers: [checkWord, uuid],
      timeout: cdk.Duration.minutes(3),
    });

    const repeatNumberLambda = new lambda.Function(this, "repeatPhoneNumber", {
      code: lambda.Code.fromAsset("lambda"),
      handler: "repeatPhoneNumber.handler",
      runtime: lambda.Runtime.NODEJS_14_X,
    });

    /**
     * permissions to dynamo from lambda
     */
    bestVanities.grantReadWriteData(convertToVanityLambda);
  }
}
