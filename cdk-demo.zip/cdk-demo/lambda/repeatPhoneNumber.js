exports.handler = async (event) => {
  const phoneNumber = event["Details"]["Parameters"]["customerPhoneNumber"];
  console.log("This is the event: ", event);

  // split phoneNumber into array
  const phoneNumberArray = phoneNumber.split("");

  // loop through phoneNumberArray and output one digit at a time
  let ssml = "<speak>";
  phoneNumberArray.forEach((digit) => (ssml = ssml + "<break/>" + digit));
  ssml = ssml + "</speak>";

  console.log(ssml);

  const response = { customerPhoneNumber: ssml };

  console.log(response);

  return response;
};
