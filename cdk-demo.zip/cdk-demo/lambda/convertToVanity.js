exports.handler = async (event) => {
  // import resources
  const checkWord = require("check-word");
  const aws = require("aws-sdk");
  const { v4 } = require("uuid");

  // initialize resources
  const dictionary = checkWord("en");
  const dynamodb = new aws.DynamoDB.DocumentClient();
  const tableName = process.env.TABLENAME;

  const phoneNumber = event["Details"]["Parameters"]["customerPhoneNumber"];
  const digits = phoneNumber.slice(-10);
  const vowels = ["a", "e", "i", "o", "u", "y"];

  console.log("phoneNumber: ", phoneNumber);
  console.log("digits: ", digits);

  const char_map = {
    0: "0",
    1: "1",
    2: "abc",
    3: "def",
    4: "ghi",
    5: "jkl",
    6: "mno",
    7: "pqrs",
    8: "tuv",
    9: "wxyz",
  };

  /**
   * Function that returns all the letter
   * combinations for a set of digits
   * @param {String} digits phone number without the additional codes
   * @returns {Array} result of all letter combinations
   */
  function letterCombinations(digits) {
    let result = [];
    if (!digits.length) {
      return [];
    }
    function getCombinations(pointer, combination) {
      if (pointer === digits.length) {
        result.push(combination);
      } else {
        let letters = char_map[digits[pointer]];
        for (let i = 0; i < letters.length; i++) {
          getCombinations(pointer + 1, combination + letters[i]);
        }
      }
    }
    getCombinations(0, "");
    return result;
  }

  // get the letter combinations for the phone number
  const combinations = letterCombinations(digits);

  // grab 3 random letter combinations as the possible vanities
  let vanityNumbers = [];
  for (let i = 0; i < 3; i++) {
    // check to see which ones have vowels
    vanityNumbers.push(
      combinations[Math.floor(Math.random() * combinations.length)]
    );
  }

  /**
   * Loop through the vanity numbers and
   * find the one that has the most vowels
   */
  let count = 0,
    best = [];
  vanityNumbers.forEach((vanity) => {
    let vowelCount = 0;
    for (let i = 0; i < vanity.length; i++) {
      if (vowels.includes(vanity[i])) {
        vowelCount++;
      }
    }
    if (vowelCount > count) {
      best.splice(0, 1, vanity);
      count = vowelCount;
    }
  });
  console.log("Best: ", best);

  let ssml = "<speak>";
  if (vanityNumbers.length) {
    //save the best to dynamo
    if (best.length) {
      try {
        const params = {
          TableName: tableName,
          Item: {
            id: v4(),
            customerPhoneNumber: phoneNumber,
            best: best[0],
            createdDate: new Date().toJSON().slice(0, 10).replace(/-/g, "/"),
          },
        };
        const save = await dynamodb.put(params).promise();
      } catch (err) {
        console.log(err);
      }
    } //end if best

    // output ssml version of the vanity numbers
    ssml = ssml + "Your possible vanity numbers are";
    vanityNumbers.forEach((item) => (ssml = ssml + "<break/>" + item));
  } else {
    ssml =
      ssml + "There are no phonetic vanity numbers for your number. Goodbye.";
  }
  ssml = ssml + "</speak>";
  let response = { vanityNumbers: ssml };

  console.log(response);

  return response;
};
